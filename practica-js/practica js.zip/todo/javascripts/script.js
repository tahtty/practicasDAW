$(document).ready(function(){
	var t1=$(".tabs a");
	t1.click(function(event){
		cambiarTab(event.target);
	})
	});

function cambiarTab(c){
	c.addClass("active");
	if(c.getAttribute("id")==1){
		document.getElementsById("2").addClass("");
		document.getElementsById("3").addClass("");
	}else
	if(c.getAttribute("id")==2){
		document.getElementsById("1").addClass("");
		document.getElementsById("3").addClass("");
	}else
	if(c.getAttribute("id")==3){
		document.getElementsById("2").addClass("");
		document.getElementsById("1").addClass("");
	}
}