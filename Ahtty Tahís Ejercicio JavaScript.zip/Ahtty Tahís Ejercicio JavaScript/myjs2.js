window.onload=function(e){
	alert('Página cargada');
}